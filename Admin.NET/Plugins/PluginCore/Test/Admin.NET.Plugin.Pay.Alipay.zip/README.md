## 说明文档（可选）

- [] 这是一个示例插件
- [x] 感谢使用

## API

- [/SayHello](/SayHello)
  - 通过插件在运行时添加 管道Middleware, 并拦截响应

- [/api/plugins/AliWebApi](/api/plugins/AliWebApi)
  - 通过插件Controller 响应

 